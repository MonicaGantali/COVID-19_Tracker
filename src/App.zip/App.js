import React, { useState, useEffect } from "react";
import "./App.css";
import {
  MenuItem,
  FormControl,
  Select,
  Card,
  CardContent,
} from "@material-ui/core";
import InfoBox from "./InfoBox";
import LineGraph from "./LineGraph";
import Table from "./Table";
import { sortData, prettyPrintStat } from "./util";
import numeral from "numeral";
import Map from "./Map";
import "leaflet/dist/leaflet.css";

const App = () => {
  const [country, setInputCountry] = useState("worldwide");
  const [state, setInputState] = useState("state")
  const [countryInfo, setCountryInfo] = useState({});
  const [stateInfo, setStateInfo] = useState({});
  const [countries, setCountries] = useState([]);
  const [states, setStates] = useState([]);
  const [mapCountries, setMapCountries] = useState([]);
  const [mapStates, setMapStates] = useState([]);
  const [tableData, setTableData] = useState([]);
  const [casesType, setCasesType] = useState("cases");
  const [mapCenter, setMapCenter] = useState({ lat: 34.80746, lng: -40.4796 });
  const [mapZoom, setMapZoom] = useState(3);
 
  
  useEffect(() => {
    debugger;
    fetch("https://disease.sh/v3/covid-19/all")
      .then((response) => response.json())
      .then((data) => {
        setCountryInfo(data);
      });
  }, []);

  useEffect(() => {
    debugger;
    fetch("https://disease.sh/v3/covid-19/all")
      .then((response) => response.json())
      .then((data) => {
        setStateInfo(data);
      });
  }, []);

  

  useEffect(() => {
    const getCountriesData = async () => {
      fetch("https://disease.sh/v3/covid-19/countries")
        .then((response) => response.json())
        .then((data) => {
          const countries = data.map((country) => ({
            name: country.country,
            value: country.countryInfo.iso2,
          }));
          let sortedData = sortData(data);
          setCountries(countries);
          setMapCountries(data);
          setTableData(sortedData);
        });
    };

    getCountriesData();
  }, []);

  useEffect(() => {
    debugger;
    const getStatesData = async () => {
      fetch("https://disease.sh/v3/covid-19/states")
        .then((response) => response.json())
        .then((data) => {
          const states = data.map((state) => ({
            name: state.state,
           value: state.state,
          }));
          let sortedData = sortData(data);
          setStates(states);
          setMapStates(data);
          setTableData(sortedData);
        });
    };

    getStatesData();
  }, []);

  console.log(casesType);

  const onCountryChange = async (e) => {
    const countryCode = e.target.value;
debugger;
    const url =
      countryCode === "worldwide"
        ? "https://disease.sh/v3/covid-19/all"
        : `https://disease.sh/v3/covid-19/countries/${countryCode}`;
    await fetch(url)
      .then((response) => response.json())
      .then((data) => {
debugger;
        setInputCountry(countryCode);
        setCountryInfo(data);
        if(countryCode != "worldwide"){
          setMapCenter([data.countryInfo.lat, data.countryInfo.long]);
          //setMapZoom(4);
        }
      else{
       // let sortedData = sortData(data);
         // setCountries(countries);
          //setMapCountries(data);
          //setTableData(sortedData);
          setMapCenter([ 34.80746, -40.4796]);
      }
        
      });
  };

  const onStateChange = async (e) => {
    
    const stateCode = e.target.value;

    const url =
      stateCode === "state"
        ? "https://disease.sh/v3/covid-19/all"
        : `https://disease.sh/v3/covid-19/states/${stateCode}`;
    await fetch(url)
      .then((response) => response.json())
      .then((data) => {
        setInputState(stateCode);
        setCountryInfo(data);
      });
     
  };


  return (
    <div className="app">
      <div className="app__left">
        <div className="app__header">
          <h1>COVID-19 Tracker</h1>
          <FormControl className="app__dropdown">
            <Select
              variant="outlined"
              value={country}
              onChange={onCountryChange}
            >
              <MenuItem value="worldwide">Worldwide</MenuItem>
              {countries.map((country) => (
                <MenuItem value={country.value}>{country.name}</MenuItem>
              ))}
            </Select>
          </FormControl>            
             {
               country==='US' ? ( <FormControl className="app__dropdown">
               <Select
                 variant="outlined"
                 value={state}
                 onChange={onStateChange}
               >
                 <MenuItem value="state">State</MenuItem>
                 {states.map((state) => (
                   <MenuItem value={state.value}>{state.name}</MenuItem>
                 ))}
               </Select>
             </FormControl>):(null)
             }
         

        </div>
        <div className="app__stats">
          <InfoBox
            onClick={(e) => setCasesType("cases")}
            title="Coronavirus Cases"
            isRed
            active={casesType === "cases"}
            cases={prettyPrintStat(countryInfo.todayCases)}
            total={numeral(countryInfo.cases).format("0.0a")}
          />
          <InfoBox
            onClick={(e) => setCasesType("recovered")}
            title="Recovered"
            active={casesType === "recovered"}
            cases={prettyPrintStat(countryInfo.todayRecovered)}
            total={numeral(countryInfo.recovered).format("0.0a")}
          />
          <InfoBox
            onClick={(e) => setCasesType("deaths")}
            title="Deaths"
            isRed
            active={casesType === "deaths"}
            cases={prettyPrintStat(countryInfo.todayDeaths)}
            total={numeral(countryInfo.deaths).format("0.0a")}
          />
           <InfoBox
            onClick={(e) => setCasesType("tests")}
            title="TestRate"
            isBlue
            active={casesType === "testsPerOneMillion"}
            cases={prettyPrintStat(countryInfo.testsPerOneMillion)}
            total={numeral(countryInfo.tests).format("0.0a")}
          />
        </div>
        <div>
        {
               state==='state' ? (
                <Map
          countries={mapCountries}
          casesType={casesType}
          center={mapCenter}
          zoom={mapZoom}
        />):(null)
        }
        </div>
      </div>
      <Card className="app__right">
        <CardContent>
          <div className="app__information">
            <h3>Live Cases by Country</h3>
            <Table countries={tableData} />
            <h3>Worldwide new {casesType}</h3>
            <LineGraph casesType={casesType} />
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default App;
